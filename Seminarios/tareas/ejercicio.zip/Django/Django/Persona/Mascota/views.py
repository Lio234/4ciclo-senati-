from django.shortcuts import render
from django.http import HttpResponse
from .models import Persona

# Create your views here.
def mostrar_datos(request):
    datos = Persona.objects.all()
    return render(request, 'index.html', {'datos': datos})


