from django.apps import AppConfig


class MascotaConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'Mascota'
